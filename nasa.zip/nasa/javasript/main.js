const engine=document.getElementById("eng").value
const crew=document.getElementById("crew").value
let money=100000000
let fuel=0
let point=0
let crewyes=0
function engine(){
    if (eng===1){
        money-=1000000
        fuel+=50
    }
    else if (eng===2){
        money-=10000000
        fuel+=175
    }
    else if (eng===3){
        money-=15000000
        fuel+=230
    }
    else if (eng===4){
        money-=20000000
        fuel+=300
    }
    else if (eng==5){
        money-=25000000
        fuel+=250
    }
};
function crewpoints(){
    if (crew){
        money-=40000000
        crewyes=50
    };
};
function points(){
    point=(fuel/5+crewyes*(Math.floor(Math.random() * 5)))/100
};




